import { initApp } from './main.js';

document.addEventListener('DOMContentLoaded', () => {
    initApp();
});
